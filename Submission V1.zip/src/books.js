/* eslint-disable eol-last */
/* eslint-disable semi */
const books = [];

module.exports = books;